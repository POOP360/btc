import os
import sys
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes

def pad(data):
    pad_len = AES.block_size - len(data) % AES.block_size
    return data + bytes([pad_len]) * pad_len

def unpad(data):
    pad_len = data[-1]
    return data[:-pad_len]

def encrypt_file(input_file, output_file, key):
    data = open(input_file, 'rb').read()
    data = pad(data)
    iv = get_random_bytes(AES.block_size)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    encrypted = cipher.encrypt(data)
    with open(output_file, 'wb') as f:
        f.write(iv + encrypted)  # IV prepend
    print(f"[+] Encrypted '{input_file}' -> '{output_file}'")
    os.remove(input_file)  # Original file delete karna

def decrypt_file(input_file, output_file, key):
    data = open(input_file, 'rb').read()
    iv = data[:AES.block_size]
    encrypted = data[AES.block_size:]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    decrypted = cipher.decrypt(encrypted)
    decrypted = unpad(decrypted)
    with open(output_file, 'wb') as f:
        f.write(decrypted)
    print(f"[+] Decrypted '{input_file}' -> '{output_file}'")
    # Agar aap chaho to yaha bhi original encrypted file delete kar sakte hain:
    # os.remove(input_file)

def main():
    if len(sys.argv) != 4:
        print("Usage:")
        print("  python direwolf.py encrypt <file_path> <key>")
        print("  python direwolf.py decrypt <file.direwolf> <key>")
        print("\nKey must be 16, 24 or 32 characters long (AES-128/192/256).")
        sys.exit(1)

    action = sys.argv[1].lower()
    file_path = sys.argv[2]
    key_str = sys.argv[3]

    if len(key_str) not in [16, 24, 32]:
        print("[!] Error: Key length invalid! Must be 16, 24 or 32 characters.")
        sys.exit(1)

    key = key_str.encode()

    if action == 'encrypt':
        if not os.path.isfile(file_path):
            print(f"[!] Error: File '{file_path}' not found.")
            sys.exit(1)
        output_file = file_path + ".direwolf"
        encrypt_file(file_path, output_file, key)

    elif action == 'decrypt':
        if not os.path.isfile(file_path):
            print(f"[!] Error: File '{file_path}' not found.")
            sys.exit(1)
        if not file_path.endswith('.direwolf'):
            print("[!] Warning: Decrypting file without '.direwolf' extension.")
        output_file = file_path.rsplit('.', 1)[0] + "_decrypted"
        decrypt_file(file_path, output_file, key)

    else:
        print("[!] Invalid action. Use 'encrypt' or 'decrypt'.")

if __name__ == "__main__":
    main()
